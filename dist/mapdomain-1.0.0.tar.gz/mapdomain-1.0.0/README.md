# mapmydomain

mapmydomain is a Python-based tool for subdomain enumeration and sitemap creation.

## Installation

```bash
pip install mapmydomain
